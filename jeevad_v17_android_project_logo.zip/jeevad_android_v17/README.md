# Jeevad V17 Android Project

This project packages the locked Jeevad V17 web interface into an Android WebView app.

- App name: हम सबका जीवद — वोटर सर्च
- Application ID: in.jeevad.voter
- Version: 1.0-V17
- Target SDK: 36
- V17 website files are bundled under `app/src/main/assets/site/` and are not modified.

Build with Android Studio/Gradle: `./gradlew assembleDebug` (after a Gradle wrapper is configured) or use Android Studio's Build APK action.
