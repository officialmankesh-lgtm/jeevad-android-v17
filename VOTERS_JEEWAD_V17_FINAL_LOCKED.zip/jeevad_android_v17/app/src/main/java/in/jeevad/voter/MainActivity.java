package in.jeevad.voter;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.net.Uri;
import android.content.Intent;
import android.content.ContentValues;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;
import android.os.Build;
import android.webkit.ValueCallback;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {
    private WebView webView;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().setNavigationBarColor(Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(
            android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR |
            android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        );

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(Uri.parse(url));
            }
        });
        root.addView(webView, new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
        webView.loadUrl("file:///android_asset/site/index.html");

        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,
                () -> handleBackNavigation()
            );
        }
    }

    private void handleBackNavigation() {
        if (webView == null) { finish(); return; }
        webView.evaluateJavascript("window.handleAndroidBack ? window.handleAndroidBack() : false", value -> {
            if ("true".equals(value)) return;
            if (webView.canGoBack()) webView.goBack();
            else finish();
        });
    }

    private boolean handleUrl(Uri u) {
        String s = u.toString();
        if (s.startsWith("https://") || s.startsWith("http://")) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, u)); return true; } catch (Exception e) { return false; }
        }
        if (s.startsWith("file:///android_asset/site/assets/wards/") && s.toLowerCase().endsWith(".pdf")) {
            String assetPath = s.substring("file:///android_asset/".length());
            String fileName = new File(assetPath).getName();
            try {
                File dir = new File(getCacheDir(), "pdfs");
                if (!dir.exists()) dir.mkdirs();
                File out = new File(dir, fileName);
                try (InputStream in = getAssets().open(assetPath); FileOutputStream fos = new FileOutputStream(out)) {
                    byte[] buf = new byte[8192]; int n;
                    while ((n=in.read(buf))>0) fos.write(buf,0,n);
                }
                Uri contentUri = Uri.parse("content://in.jeevad.voter.fileprovider/" + fileName);
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setDataAndType(contentUri, "application/pdf");
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                try { startActivity(intent); } catch (Exception e) { Toast.makeText(this,"PDF खोलने के लिए फोन में PDF viewer नहीं मिला।",Toast.LENGTH_LONG).show(); }
                return true;
            } catch (Exception e) {
                Toast.makeText(this,"PDF खोलने में समस्या हुई।",Toast.LENGTH_SHORT).show();
                return true;
            }
        }
        return false;
    }

    @Override public void onBackPressed() {
        if (Build.VERSION.SDK_INT < 33) handleBackNavigation();
        else super.onBackPressed();
    }
}
