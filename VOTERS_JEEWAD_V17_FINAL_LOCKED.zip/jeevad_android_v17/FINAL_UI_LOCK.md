# VOTERS JEEWAD V17 — FINAL UI LOCK

This Android project uses one canonical HTML interface at `app/src/main/assets/site/index.html`.
The duplicate legacy `jeevad_v17_final/` web folder has been removed to prevent the Android build from drifting to a different UI.

Locked UI points:
- white Android system-bar areas; app content stays between them
- single hamburger menu with centered popup panel
- no duplicate right-side three-dot menu
- Jeevad logo and Gram Panchayat header
- approved service cards and quick panels
- MANKESH PRAJAPAT / “युवा शक्ति — नई सोच, नया संकल्प” section retained
- voter search, EPIC search/download, ward list, WhatsApp updates, suggestions/complaints retained
- Android Back closes open menu/panels before exiting
