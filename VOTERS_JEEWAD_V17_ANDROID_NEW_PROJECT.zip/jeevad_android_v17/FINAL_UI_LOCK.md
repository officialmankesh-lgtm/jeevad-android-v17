# V17 FINAL UI LOCK — APPROVED SCREENSHOT REFERENCE

The approved V17 interface is based on the user's final screenshots supplied on 2026-09-21.

1. Home screen: compact single-screen layout with white system bars, blue Jeevad header, hero banner, compact Services header, 2x2 service cards, WhatsApp updates row, suggestion/complaint row, and compact Youth Power section visible on the same screen.
2. Youth screen: separate expanded "युवा शक्ति — नई सोच, नया संकल्प" panel/screen with Mankesh Prajapat portrait, approved quote, name, youth role line, and youth graphic.

Do not use the previous oversized responsive layout as the visual baseline. Preserve the existing voter search, EPIC search, ward list/PDF, WhatsApp, feedback, menu, and Android back functionality.
