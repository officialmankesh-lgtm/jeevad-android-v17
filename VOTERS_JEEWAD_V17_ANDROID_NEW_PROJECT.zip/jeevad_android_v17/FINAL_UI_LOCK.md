# VOTERS JEEWAD V17 — FINAL UI LOCK

Canonical Android UI: `app/src/main/assets/site/index.html`.

Approved visual order:
1. White Android status-bar area.
2. Blue Gram Panchayat Jeevad header with ONE hamburger button, round Jeevad logo, and title/subtitle. No right-side three-dot button.
3. Digital citizen service hero: “हम सबका जीवद”.
4. Services row: “सेवाएँ” on the left and “एक क्लिक में, आपकी सुविधा” on the right.
5. Four colored service cards: voter search, EPIC search, EPIC download, ward list.
6. Full-width Latest Updates card linking to the Jeevad WhatsApp Channel.
7. Full-width Suggestions/Complaints card.
8. Lower profile section with MANKESH PRAJAPAT photo and “युवा शक्ति — नई सोच, नया संकल्प”.
9. White Android navigation-key area; app content must not sit underneath it.

Interaction lock:
- Hamburger opens one centered menu popup.
- Service panels open as fixed in-screen panels.
- Android Back closes menu/panel before leaving the app.
- Ward PDFs open externally through the Android FileProvider.
- Feedback remains local and can open WhatsApp.
- Latest Updates opens the Jeevad WhatsApp Channel.

## V17 UI correction — 21 Sep 2026
- Restored the approved right-side header profile photo using `assets/mankesh-prajapat.jpg`.
- Restored the single three-dot header menu button; it opens the same centered popup menu as the hamburger button.
- No duplicate/second menu panel is introduced.
- Existing V17 voter panels, Back handling, WhatsApp Channel, ward PDFs, feedback, and youth profile remain unchanged.
