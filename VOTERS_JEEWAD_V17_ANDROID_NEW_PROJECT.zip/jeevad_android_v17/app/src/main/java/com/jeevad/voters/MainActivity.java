package com.jeevad.voters;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.content.Intent;
import android.net.Uri;

public class MainActivity extends Activity {
  WebView web;
  @Override public void onCreate(Bundle b){ super.onCreate(b);
    getWindow().setStatusBarColor(Color.WHITE); getWindow().setNavigationBarColor(Color.WHITE);
    getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
    web=new WebView(this); setContentView(web);
    WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false); s.setSupportZoom(false); s.setTextZoom(100);
    web.setVerticalScrollBarEnabled(false); web.setOverScrollMode(View.OVER_SCROLL_NEVER);
    web.setWebViewClient(new WebViewClient(){ @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r){ String u=r.getUrl().toString(); if(u.startsWith("http://")||u.startsWith("https://")||u.startsWith("tel:")){ try{ startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u))); }catch(Exception e){} return true;} return false; }});
    web.addJavascriptInterface(new Object(){ @android.webkit.JavascriptInterface public void noop(){} }, "Android");
    web.loadUrl("file:///android_asset/index.html");
  }
  @Override public void onBackPressed(){ if(web!=null){ web.evaluateJavascript("(function(){var ids=['ov','actionOv','epicOv','wardOv']; for(var i=0;i<ids.length;i++){var e=document.getElementById(ids[i]); if(e && getComputedStyle(e).display!=='none'){e.style.display='none'; return 'closed';}} return 'none';})()", null); } super.onBackPressed(); }
}
