# Jeevad V17 Final

Final Android project based on the approved V17 interface draft.

Included:
- V17 voter-search baseline and voter data/assets
- App logo and Jeevad branding
- White Android status/navigation bars
- Light, minimal app border
- Header profile photo with proper fit
- Three-dot menu with Home, voter search, ward list, WhatsApp updates, suggestions/complaints, About, Privacy, contact and official-source links
- In-screen fixed popup panels for voter search, EPIC search/download, ward list, updates and feedback
- Android physical Back button support for menu/panels
- Ward PDF external opening via FileProvider
- Feedback saved locally and WhatsApp submission to 9983140879
- Latest Updates opens the Jeevad WhatsApp Channel
- App version: V17 Final

Build:
- compileSdk 36
- targetSdk 36
- Java 17
- Gradle 8.11.1 / Android Gradle Plugin 8.9.2 (as used by the project)
