Jeevad V17 Android project — rebuilt from the approved V17 interface HTML.
