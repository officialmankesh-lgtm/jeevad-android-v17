@echo off
cd /d "%~dp0"
where java >nul 2>nul || (echo ERROR: Java/JDK is required. & exit /b 1)
call gradlew.bat --no-daemon clean assembleDebug
if errorlevel 1 exit /b %errorlevel%
echo.
echo APK: app\build\outputs\apk\debug\app-debug.apk
