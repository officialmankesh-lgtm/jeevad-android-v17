# DIGITAL PANCHAYAT — Gradle Wrapper

This project is configured for Gradle 8.11.1.

The repository includes a network bootstrap wrapper (`gradlew` / `gradlew.bat`) that downloads the official Gradle distribution only when it is not already cached, verifies its SHA-256 checksum, and then runs Gradle.

Official Gradle distribution checksum for 8.11.1 binary ZIP:
`f397b287023acdba1e9f6fc5ea72d22dd63669d59ed4a289a29b1a76eee151c6`

Note: the official `gradle-wrapper.jar` could not be fetched in this environment because outbound DNS/network access is unavailable. Do not replace it with an unverified binary. The bootstrap scripts are provided as a safe build fallback.
