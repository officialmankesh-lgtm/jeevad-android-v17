#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
if [ ! -x ./gradlew ]; then
  echo "ERROR: gradlew missing" >&2; exit 1
fi
if ! command -v java >/dev/null 2>&1; then
  echo "ERROR: Java is required (JDK 17 recommended)." >&2; exit 1
fi
./gradlew --no-daemon clean assembleDebug
printf '\nAPK: app/build/outputs/apk/debug/app-debug.apk\n'
