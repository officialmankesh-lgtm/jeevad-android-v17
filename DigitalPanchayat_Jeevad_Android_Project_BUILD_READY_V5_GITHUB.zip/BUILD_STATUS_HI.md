# DIGITAL PANCHAYAT — वर्तमान Build स्थिति

## तैयार
- Android application module
- Gradle 8.11.1 configuration
- Android Gradle Plugin 8.9.2
- compileSdk 35 / targetSdk 35 / minSdk 23
- Java 17 source/target compatibility
- Gradle distribution SHA-256 verification
- `gradlew` और `gradlew.bat` bootstrap scripts
- Ward 1–9 voter PDFs bundled in the project
- `build-apk.sh` और `build-apk.bat` build commands

## अंतिम बाहरी आवश्यकता
इस environment में Android SDK/Build Tools और official Gradle distribution download उपलब्ध नहीं है। इसलिए यहाँ `assembleDebug` को वास्तव में execute करके APK बनाना/verify करना संभव नहीं है।

## APK build command
Linux/macOS:
```sh
./build-apk.sh
```
Windows:
```bat
build-apk.bat
```
Output:
`app/build/outputs/apk/debug/app-debug.apk`
