# DIGITAL PANCHAYAT — Build Configuration

## Project
जीवद ग्राम पंचायत — DIGITAL PANCHAYAT

## Build stack
- Android Gradle Plugin: 8.9.2
- Gradle: 8.11.1
- compileSdk: 35
- targetSdk: 35
- minSdk: 23
- Java/JDK: 17 recommended

## Build command
Linux/macOS:
`./gradlew assembleDebug`

Windows:
`gradlew.bat assembleDebug`

Release:
`./gradlew assembleRelease`

## Important
पहली बार build के लिए internet चाहिए ताकि Gradle 8.11.1 download हो सके। Android SDK Platform 35 और Build Tools भी मशीन में installed होने चाहिए।

इस project में Ward 1–9 की voter PDFs assets में रखी गई हैं।
