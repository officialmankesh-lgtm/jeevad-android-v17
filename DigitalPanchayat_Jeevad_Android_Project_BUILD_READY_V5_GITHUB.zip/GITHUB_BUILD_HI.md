# DIGITAL PANCHAYAT — GitHub APK Build

इस project में GitHub Actions सीधे Gradle 8.11.1 उपलब्ध कराता है। इसलिए `gradlew` में Gradle distribution डाउनलोड होने पर निर्भर नहीं रहना पड़ता।

## Build
1. पूरा project GitHub repository में upload करें।
2. Branch का नाम `main` रखें।
3. GitHub में **Actions → Build Digital Panchayat APK → Run workflow** चुनें।
4. Build पूरा होने पर **Artifacts → DigitalPanchayat-Jeevad-debug-apk** से APK प्राप्त करें।

Workflow Android SDK 35, Build Tools 35.0.0 और Java 17 सेट करता है और फिर `gradle assembleDebug` चलाता है।
