# DIGITAL PANCHAYAT — APK बनाने का अगला कदम

यह project GitHub Actions के लिए तैयार है। Local computer में Android SDK/Gradle लगाने की जरूरत नहीं है।

## GitHub पर चलाने के चरण
1. GitHub में नया **Private repository** बनाएं, उदाहरण: `DigitalPanchayat-Jeevad`.
2. इस ZIP को extract करें और पूरे project के अंदर की सभी files repository में upload करें।
3. GitHub में **Actions** खोलें।
4. **Build DIGITAL PANCHAYAT APK** workflow चुनें।
5. **Run workflow** दबाएं।
6. पूरा होने पर green check आएगा।
7. नीचे **Artifacts** में `DigitalPanchayat-Jeevad-debug-apk` मिलेगा।
8. उसमें `app-debug.apk` डाउनलोड करके Android फोन में install करें।

## अगर लाल error आए
Actions → failed run → **Build debug APK** के अंदर जो लाल error दिखे, उसका screenshot भेजें। उसी error के अनुसार source ठीक किया जाएगा।

## ध्यान
यह debug APK है और testing के लिए है। Play Store के लिए बाद में signed release build अलग से तैयार किया जाएगा।
