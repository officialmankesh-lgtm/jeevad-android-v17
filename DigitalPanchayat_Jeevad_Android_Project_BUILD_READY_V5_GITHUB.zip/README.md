# DIGITAL PANCHAYAT — जीवद ग्राम पंचायत

Android WebView project based on the existing Jeevad V17 Android project/build configuration.

Application ID: in.jeewad.digitalpanchayat
Target SDK: 35
Default language: Hindi; English toggle included in the app UI.

The existing voter interface is retained under app/src/main/assets/site/voter.html and its ward PDFs/assets remain bundled.

Build system: Android Gradle Plugin 8.9.2. AGP 8.9 requires Gradle 8.11.1 and JDK 17 according to Android's compatibility documentation.
