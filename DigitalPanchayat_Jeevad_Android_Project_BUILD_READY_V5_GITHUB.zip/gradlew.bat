@echo off
setlocal EnableExtensions
set "APP_HOME=%~dp0"
set "GRADLE_VERSION=8.11.1"
set "DIST_NAME=gradle-%GRADLE_VERSION%-bin.zip"
set "DIST_URL=https://services.gradle.org/distributions/%DIST_NAME%"
set "DIST_SHA256=f397b287023acdba1e9f6fc5ea72d22dd63669d59ed4a289a29b1a76eee151c6"
if not defined GRADLE_USER_HOME set "GRADLE_USER_HOME=%USERPROFILE%\.gradle"
set "CACHE_DIR=%GRADLE_USER_HOME%\wrapper\dists\digitalpanchayat-%GRADLE_VERSION%"
set "DIST_ZIP=%CACHE_DIR%\%DIST_NAME%"
set "DIST_DIR=%CACHE_DIR%\gradle-%GRADLE_VERSION%"
if exist "%DIST_DIR%\bin\gradle.bat" goto RUN
if not exist "%CACHE_DIR%" mkdir "%CACHE_DIR%"
if not exist "%DIST_ZIP%" (
  echo Downloading Gradle %GRADLE_VERSION%...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing -Uri '%DIST_URL%' -OutFile '%DIST_ZIP%'"
  if errorlevel 1 exit /b 1
)
for /f "skip=1 tokens=*" %%H in ('certutil -hashfile "%DIST_ZIP%" SHA256') do if not defined HASH set "HASH=%%H"
set "HASH=%HASH: =%"
if /I not "%HASH%"=="%DIST_SHA256%" (
  echo ERROR: Gradle ZIP checksum mismatch.
  del /q "%DIST_ZIP%" 2>nul
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%DIST_ZIP%' '%CACHE_DIR%'"
if errorlevel 1 exit /b 1
:RUN
call "%DIST_DIR%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
